Set WshShell = CreateObject("WScript.Shell")

' Запускаем socat в скрытом режиме
WshShell.Run "powershell.exe -ExecutionPolicy Bypass -WindowStyle Hidden -Command ""Start-Process 'socat.exe' -ArgumentList 'TCP4-LISTEN:6987,fork UDP4:nicely-validation.tun.ply.gg:12120' -WindowStyle Hidden""", 0, False

' Выводим маленькое системное уведомление в углу экрана
WshShell.Popup "Мост успешно запущен и работает!", 3, "Системное сообщение", 64